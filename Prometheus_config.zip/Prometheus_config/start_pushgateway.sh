#!/bin/bash
nohup /usr/local/pushgateway/pushgateway & &>> pushgateway.log
