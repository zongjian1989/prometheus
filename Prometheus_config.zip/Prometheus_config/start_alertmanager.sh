#!/bin/bash

nohup /usr/local/alertmanager/alertmanager --web.listen-address="192.168.10.4:9093"  &>> /usr/local/alertmanager/alertmanager.log &
