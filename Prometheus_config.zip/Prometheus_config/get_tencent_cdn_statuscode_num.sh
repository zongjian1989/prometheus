#!/bin/bash

sleep 15

PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin:$PATH

start_time=`date +'%F %T' -d '5 minutes ago'`
end_time=`date +'%F %T'`

echo $start_time
echo $end_time

result=`tccli cdn DescribeCdnData --cli-unfold-argument  --StartTime "$start_time" --EndTime "$end_time" --Metric statusCode --Domains captive.samsungconnectivity.com --Project 0 2>/dev/null`

rt_code=$?

i=0

while [ $rt_code -ne 0 -a $i -lt 5 ]
do
	sleep 2
	result=`tccli cdn DescribeCdnData --cli-unfold-argument  --StartTime "$start_time" --EndTime "$end_time" --Metric statusCode --Domains captive.samsungconnectivity.com --Project 0`
	rt_code=$?
	i=$(($i+1))
done

if [ $rt_code -ne 0 ];then
        curl -X DELETE http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
        curl -X DELETE http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
        curl -X DELETE http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
        curl -X DELETE http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
        curl -X DELETE http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
        curl -X DELETE http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
        exit 0
fi

cdndata=`echo $result | jq '.Data[0].CdnData[]'`
detaildata_5xx=`echo $cdndata | jq '. | select(.Metric == "5xx") | .DetailData'`
detaildata_4xx=`echo $cdndata | jq '. | select(.Metric == "4xx") | .DetailData'`
detaildata_3xx=`echo $cdndata | jq '. | select(.Metric == "5xx") | .DetailData'`
detaildata_2xx=`echo $cdndata | jq '. | select(.Metric == "2xx") | .DetailData'`
detaildata_0xx=`echo $cdndata | jq '. | select(.Metric == "0") | .DetailData'`


num_5xx=`echo $detaildata_5xx | jq .[-1].Value`
num_4xx=`echo $detaildata_4xx | jq .[-1].Value`
num_3xx=`echo $detaildata_3xx | jq .[-1].Value`
num_2xx=`echo $detaildata_2xx | jq .[-1].Value`
num_0xx=`echo $detaildata_0xx | jq .[-1].Value`

num_statuscode=$(($num_0xx + $num_2xx + $num_3xx + $num_4xx + $num_5xx))

echo "tencent_cdn_5xx_num $num_5xx" | curl --data-binary @- http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
echo "tencent_cdn_4xx_num $num_4xx" | curl --data-binary @- http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
echo "tencent_cdn_3xx_num $num_3xx" | curl --data-binary @- http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
cat << EOF | curl --data-binary @- http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
#TYPE tencent_cdn_2xx_num gauge
tencent_cdn_2xx_num $num_2xx
EOF
#echo "tencent_cdn_2xx_num $num_2xx" | curl --data-binary @- http://192.168.10.4:9091/metrics/job/tencent_cdn_2xx/instance/192.168.10.4/domain/captive.samsungconnectivity.com
echo "tencent_cdn_0xx_num $num_0xx" | curl --data-binary @- http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
echo "tencent_cdn_statuscode_num $num_statuscode" | curl --data-binary @- http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
