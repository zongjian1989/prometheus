#!/bin/bash

declare -i a
declare -i b


a=100
b=0

while [ "$a" -eq "100" -a "$b" -lt 3  ]
do
	sleep 1
	b=$(($b+1))
	echo $a
	if [ "$b" -eq "3" ];then
		a=3
	fi
done


echo $a

