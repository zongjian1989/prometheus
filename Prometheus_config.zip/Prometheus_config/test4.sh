#!/bin/bash

PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin:$PATH

start_time=`date +'%F %T' -d '5 minutes ago'`
end_time=`date +'%F %T'`

echo $start_time
echo $end_time


tccli cdn DescribeCdnData --cli-unfold-argument  --StartTime "$start_time" --EndTime "$end_time" --Metric statusCode --Domains captive.samsungconnectivity.com --Project 0

result=`tccli cdn DescribeCdnData --cli-unfold-argument  --StartTime "$start_time" --EndTime "$end_time" --Metric statusCode --Domains captive.samsungconnectivity.com --Project 0`
echo $?
if [ $? == 0 ];then
	echo OK
fi

cdndata=`tccli cdn DescribeCdnData --cli-unfold-argument  --StartTime "$start_time" --EndTime "$end_time" --Metric statusCode --Domains captive.samsungconnectivity.com --Project 0 | jq '.Data[0].CdnData[]'`


detaildata_5xx=`echo $cdndata | jq '. | select(.Metric == "5xx") | .DetailData' `
detaildata_4xx=`echo $cdndata | jq '. | select(.Metric == "4xx") | .DetailData' `
detaildata_3xx=`echo $cdndata | jq '. | select(.Metric == "5xx") | .DetailData' `
detaildata_2xx=`echo $cdndata | jq '. | select(.Metric == "5xx") | .DetailData' `
detaildata_0=`echo $cdndata | jq '. | select(.Metric == "0") | .DetailData' `

echo $detaildata_5xx
